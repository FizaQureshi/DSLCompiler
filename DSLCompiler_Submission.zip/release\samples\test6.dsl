contract Test {

uint a = 10;
uint b = 20;

if(a < b)
{
    return a;
}
else
{
    return b;
}

}