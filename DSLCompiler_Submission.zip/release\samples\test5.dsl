contract Test {

uint a = 10;

a = a + 5;

return a;

}