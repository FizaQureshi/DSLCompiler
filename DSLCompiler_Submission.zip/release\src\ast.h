#pragma once

#include <string>
#include <vector>

struct Expr
{
    virtual ~Expr() {}
};

struct NumberExpr : Expr
{
    int value;

    NumberExpr(int v)
        : value(v)
    {}
};

struct VariableExpr : Expr
{
    std::string name;

    VariableExpr(const std::string& n)
        : name(n)
    {}
};

struct BinaryExpr : Expr
{
    std::string op;

    Expr* left;
    Expr* right;

    BinaryExpr(
        const std::string& o,
        Expr* l,
        Expr* r
    )
        : op(o),
          left(l),
          right(r)
    {}
};

struct VariableDecl
{
    std::string type;
    std::string name;
    Expr* expr;
};


struct Parameter
{
    std::string type;
    std::string name;
};

struct Statement
{
    virtual ~Statement() {}
};

struct VariableDeclStmt : Statement
{
    VariableDecl var;

    VariableDeclStmt(
        const VariableDecl& v
    )
        : var(v)
    {}
};

struct AssignmentStmt : Statement
{
    std::string name;
    Expr* expr;

    AssignmentStmt(
        const std::string& n,
        Expr* e
    )
        : name(n),
          expr(e)
    {}
};

struct ReturnStmt : Statement
{
    Expr* expr;

    ReturnStmt(Expr* e)
        : expr(e)
    {}
};

struct ExpressionStmt : Statement
{
    Expr* expr;

    ExpressionStmt(Expr* e)
        : expr(e)
    {}
};

struct IfStmt : Statement
{
    Expr* condition;

    std::vector<Statement*> thenBlock;

    std::vector<Statement*> elseBlock;

    IfStmt(
        Expr* cond
    )
        : condition(cond)
    {}
};

struct Function
{
    std::string name;

    std::vector<Parameter> params;

    std::string returnType;

    std::vector<Statement*> body;
};

struct BoolExpr : Expr
{
    bool value;

    BoolExpr(bool v)
        : value(v)
    {}
};

struct AddressExpr : Expr
{
    std::string value;

    AddressExpr(const std::string& v)
        : value(v)
    {}
};

struct UnaryExpr : Expr
{
    std::string op;
    Expr* operand;

    UnaryExpr(
        const std::string& o,
        Expr* expr
    )
        : op(o),
          operand(expr)
    {}
};

struct FunctionCallExpr : Expr
{
    std::string name;

    std::vector<Expr*> args;

    FunctionCallExpr(
        const std::string& n
    )
        : name(n)
    {}
};