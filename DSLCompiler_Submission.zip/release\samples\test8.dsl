contract Test {

uint result = add(10, 20);

function add(
    uint a,
    uint b
)
public
returns(uint)
{
    return a + b;
}

}