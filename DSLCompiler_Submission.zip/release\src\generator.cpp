#include "generator.h"
#include <iostream>
std::string exprToCpp(Expr* expr)
{
    if(auto n = dynamic_cast<NumberExpr*>(expr))
        return std::to_string(n->value);

    if(auto v = dynamic_cast<VariableExpr*>(expr))
        return v->name;

    if(auto f = dynamic_cast<FunctionCallExpr*>(expr))
    {
        std::string code;

        code += f->name;

        code += "(";

        for(size_t i = 0; i < f->args.size(); i++)
        {
            code += exprToCpp(
                f->args[i]
            );

            if(i + 1 < f->args.size())
                code += ", ";
        }

        code += ")";

        return code;
    }

    if(auto b = dynamic_cast<BinaryExpr*>(expr))
    {
        return "("
            + exprToCpp(b->left)
            + " "
            + b->op
            + " "
            + exprToCpp(b->right)
            + ")";
    }

    if(auto b = dynamic_cast<BoolExpr*>(expr))
    {
        return b->value ? "true" : "false";
    }

    if(auto u = dynamic_cast<UnaryExpr*>(expr))
    {
        return "("
            + u->op
            + exprToCpp(u->operand)
            + ")";
    }

    if(auto a = dynamic_cast<AddressExpr*>(expr))
    {
        return "\"" + a->value + "\"";
    }

    return "";
}

std::string blockToCpp(
    const std::vector<Statement*>& block
)
{
    std::string result;

    for(auto stmt : block)
    {
        result += "    ";
        result += statementToCpp(stmt);
        result += "\n";
    }

    return result;
}

std::string solidityTypeToCpp(
    const std::string& type
)
{
    if(type == "uint")
        return "unsigned long long";

    if(type == "int")
        return "long long";

    if(type == "bool")
        return "bool";

    if(type == "address")
        return "std::string";

    return "void";
}

std::string statementToCpp(Statement* stmt)
{
    if(auto a = dynamic_cast<AssignmentStmt*>(stmt))
    {
        return a->name
            + " = "
            + exprToCpp(a->expr)
            + ";";
    }

    if(auto r = dynamic_cast<ReturnStmt*>(stmt))
    {
        return "return "
            + exprToCpp(r->expr)
            + ";";
    }

    if(auto i = dynamic_cast<IfStmt*>(stmt))
    {
        std::string code;

        code += "if(";
        code += exprToCpp(i->condition);
        code += ")\n{\n";

        code += blockToCpp(i->thenBlock);

        code += "}";

        if(!i->elseBlock.empty())
        {
            code += "\nelse\n{\n";

            code += blockToCpp(i->elseBlock);

            code += "}";
        }

        return code;
    }

    if(auto e = dynamic_cast<ExpressionStmt*>(stmt))
    {
        return exprToCpp(e->expr) + ";";
    }

    if(auto v =
    dynamic_cast<VariableDeclStmt*>(stmt))
    {
        std::string code;

        code += solidityTypeToCpp(
            v->var.type
        );

        code += " ";

        code += v->var.name;

        if(v->var.expr)
        {
            code += " = ";
            code += exprToCpp(v->var.expr);
        }

        code += ";";

        return code;
    }

    return "";
}


std::string functionToCpp(
    const Function& fn
)
{
    std::string code;

    code += solidityTypeToCpp(fn.returnType);

    code += " ";

    code += fn.name;

    code += "(";

    for(size_t i = 0; i < fn.params.size(); i++)
    {
        code += solidityTypeToCpp(
            fn.params[i].type
        );

        code += " ";

        code += fn.params[i].name;

        if(i + 1 < fn.params.size())
            code += ", ";
    }

    code += ")\n{\n";

    for(auto stmt : fn.body)
    {
        code += "    ";
        code += statementToCpp(stmt);
        code += "\n";
    }

    code += "}\n\n";

    return code;
}

void generateCpp(
    const std::vector<VariableDecl>& vars,
    const std::vector<Statement*>& statements,
    const std::vector<Function>& functions
)
{
    std::cout << "Generating C++ code...\n";

    std::ofstream out("output.cpp");

    out << "#include <iostream>\n";
    out << "#include <string>\n\n";

    for(const auto& fn : functions)
    {
        out << functionToCpp(fn);
    }
    out << "int main()\n{\n";


    for(const auto& v : vars)
    {
        std::string cppType;

        if(v.type == "uint")
            cppType = "unsigned long long";

        else if(v.type == "int")
            cppType = "long long";

        else if(v.type == "bool")
            cppType = "bool";

        else if(v.type == "address")
            cppType = "std::string";

        out << cppType << " "
            << v.name;

        if(v.expr)
            out << " = " << exprToCpp(v.expr);

        out << ";\n";
    }

    for(const auto& stmt : statements)
    {
        out << statementToCpp(stmt) << "\n";
    }

    out << "}\n";
}