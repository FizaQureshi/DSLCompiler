#include <iostream>
#include <cstdio>

extern int yyparse();
extern FILE* yyin;

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        std::cout << "Usage: dsl_to_cpp <file.dsl>\n";
        return 1;
    }

    yyin = fopen(argv[1], "r");

    if(!yyin)
    {
        std::cout << "Cannot open file\n";
        return 1;
    }

    std::cout << "Starting parser...\n";

    yyparse();

    fclose(yyin);

    return 0;
}