contract Test {

uint x = 10;

function max(
    uint a,
    uint b
)
public
returns(uint)
{
    if(a > b)
    {
        return a;
    }

    return b;
}

}