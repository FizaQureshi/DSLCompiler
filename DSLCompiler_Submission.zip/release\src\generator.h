#pragma once

#include <fstream>
#include <vector>
#include <string>
#include "ast.h"

std::string exprToCpp(Expr* expr);
std::string statementToCpp(Statement* stmt);

void generateCpp(
    const std::vector<VariableDecl>& vars,
    const std::vector<Statement*>& statements,
    const std::vector<Function>& functions
);