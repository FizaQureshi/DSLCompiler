contract Test {

uint a = 5 + 3 * 2;

uint b = (a - 1) / 2;

}