contract Test {

function add(
    uint a,
    uint b
)
public
returns(uint)
{
    return a + b;
}

add(10,20);

}