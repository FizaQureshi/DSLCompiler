contract Test {

uint result = add(add(1,2), 3);

function add(
    uint a,
    uint b
)
public
returns(uint)
{
    return a + b;
}

}