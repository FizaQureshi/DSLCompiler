contract Test {

uint a = 10;

uint b = 20;

bool c = a < b;

bool d = a != b;

bool e = c && d;

bool f = !e;

}