contract Test {

    function add(
        uint a,
        uint b
    )
    public
    returns(uint)
    {
        uint result = a + b;

        return result;
    }

}