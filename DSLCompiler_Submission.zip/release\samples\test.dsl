contract MyContract {
    uint a = 5;
    uint b;
}