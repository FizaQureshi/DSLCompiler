contract Test {

int x = -10;
int b = -(10 + 20);

}