contract Test {

uint a = 10;

int b = 20;

bool active = true;

address owner;

}