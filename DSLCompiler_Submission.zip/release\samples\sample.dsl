contract Test {

address owner =
0x1234567890abcdef1234567890abcdef12345678;

}