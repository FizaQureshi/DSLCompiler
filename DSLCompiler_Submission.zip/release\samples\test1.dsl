contract MyContract {
    uint a = 5 + 3 * 2;
}