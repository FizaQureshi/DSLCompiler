%{

#include <stdio.h>
#include <vector>
#include "ast.h"
#include "generator.h"
#include <cstring>
#include <string.h>

void yyerror(const char *s);
int yylex();
std::vector<VariableDecl> variables;
std::vector<Statement*> statements;
std::vector<Function> functions;

%}

%code requires
{
    #include <vector>
    #include "ast.h"
}

%union
{
    int ival;
    char* sval;
    Expr* expr;
    Statement* stmt;
    std::vector<Statement*>* stmtList;
    Parameter* param;
    std::vector<Parameter>* paramList;
    Function* func;
    std::vector<Expr*>* exprList;
};

%token CONTRACT
%token UINT
%token <sval> IDENTIFIER
%token <sval> ADDRESS_LITERAL
%token <ival> NUMBER
%token INT
%token BOOL
%token ADDRESS

%token TRUE
%token FALSE

%token EQ
%token NEQ

%token GT
%token LT
%token GTE
%token LTE

%token AND
%token OR
%token NOT

%token IF
%token ELSE

%token RETURN
%token FUNCTION
%token PUBLIC
%token RETURNS


%type <expr> expression
%type <sval> type
%type <stmt> statement
%type <stmtList> block
%type <stmtList> statement_list
%type <param> parameter
%type <paramList> parameter_list
%type <exprList> argument_list
%type <stmt> local_var_decl


%left OR
%left AND

%left EQ NEQ

%left GT LT GTE LTE

%left '+' '-'

%left '*' '/' '%'

%right NOT UMINUS

%start program

%%

contract_item:
      declaration
    {
    }

    | statement
    {
        statements.push_back($1);
    }

    | function_def
    {
    }
;

contract_items:
      contract_items contract_item
    |
;

program:
    CONTRACT IDENTIFIER '{'
        contract_items
    '}'
    {
        generateCpp(variables,statements,functions);
        printf("Valid Contract!\n");
        printf("Variables: %zu\n", variables.size());
        printf("Functions: %zu\n", functions.size());
    }
;

declarations:
      declarations declaration
    |
;

type:
      UINT    { $$ = strdup("uint"); }
    | INT     { $$ = strdup("int"); }
    | BOOL    { $$ = strdup("bool"); }
    | ADDRESS { $$ = strdup("address"); }
;

declaration:
      type IDENTIFIER ';'
      {
          VariableDecl var;
          var.type = $1;
          var.name = $2;
          var.expr = nullptr;

          variables.push_back(var);
      }

    | type IDENTIFIER '=' expression ';'
      {
          VariableDecl var;
          var.type = $1;
          var.name = $2;
          var.expr = $4;

          variables.push_back(var);
      }
;

statement_list:
      statement_list statement
      {
          $1->push_back($2);
          $$ = $1;
      }

    | statement
      {
          $$ = new std::vector<Statement*>();
          $$->push_back($1);
      }

    |
      {
          $$ = new std::vector<Statement*>();
      }
;

block:
      '{' statement_list '}'
      {
          $$ = $2;
      }
;

statement:
      local_var_decl

    |  IDENTIFIER '=' expression ';'
      {
          $$ = new AssignmentStmt($1, $3);
      }

    | RETURN expression ';'
      {
          $$ = new ReturnStmt($2);
      }

    | IF '(' expression ')' block
    {
        IfStmt* ifStmt = new IfStmt($3);

        ifStmt->thenBlock = *$5;

        $$ = ifStmt;
    }

    | IF '(' expression ')' block ELSE block
    {
        IfStmt* ifStmt = new IfStmt($3);

        ifStmt->thenBlock = *$5;
        ifStmt->elseBlock = *$7;

        $$ = ifStmt;
    }

    | expression ';'
    {
        $$ = new ExpressionStmt($1);
    }
;

top_level_statements:
      statement_list
      {
          statements = *$1;
      }
;

parameter:
      type IDENTIFIER
      {
          Parameter* p = new Parameter();

          p->type = $1;
          p->name = $2;

          $$ = p;
      }
;

parameter_list:
      parameter
      {
          $$ = new std::vector<Parameter>();

          $$->push_back(*$1);
      }

    | parameter_list ',' parameter
      {
          $1->push_back(*$3);

          $$ = $1;
      }

    |
      {
          $$ = new std::vector<Parameter>();
      }
;

function_def:
      FUNCTION IDENTIFIER
      '(' parameter_list ')'
      PUBLIC
      RETURNS '(' type ')'
      block
      {
          Function fn;

          fn.name = $2;

          fn.params = *$4;

          fn.returnType = $9;

          fn.body = *$11;

          functions.push_back(fn);
      }
;

function_list:
      function_list function_def
    |
;


argument_list:
      expression
      {
          $$ = new std::vector<Expr*>();

          $$->push_back($1);
      }

    | argument_list ',' expression
      {
          $1->push_back($3);

          $$ = $1;
      }

    |
      {
          $$ = new std::vector<Expr*>();
      }
;

expression:
      NUMBER
      {
          $$ = new NumberExpr($1);
      }

      | ADDRESS_LITERAL
        {
            $$ = new AddressExpr($1);
        }

      | IDENTIFIER '(' argument_list ')'
        {
            FunctionCallExpr* call =
                new FunctionCallExpr($1);

            call->args = *$3;

            $$ = call;
        }

    | IDENTIFIER
      {
          $$ = new VariableExpr($1);
      }

    | expression '+' expression
      {
          $$ = new BinaryExpr("+", $1, $3);
      }

    | expression '-' expression
      {
          $$ = new BinaryExpr("-", $1, $3);
      }

    | expression '*' expression
      {
          $$ = new BinaryExpr("*", $1, $3);
      }

    | expression '/' expression
      {
          $$ = new BinaryExpr("/", $1, $3);
      }

    | '(' expression ')'
      {
          $$ = $2;
      }

    | expression '%' expression
        {
            $$ = new BinaryExpr("%", $1, $3);
        }

    | expression EQ expression
        {
            $$ = new BinaryExpr("==", $1, $3);
        }

    | expression NEQ expression
        {
            $$ = new BinaryExpr("!=", $1, $3);
        }

    | expression GT expression
        {
            $$ = new BinaryExpr(">", $1, $3);
        }

    | expression LT expression
        {
            $$ = new BinaryExpr("<", $1, $3);
        }

    | expression GTE expression
        {
            $$ = new BinaryExpr(">=", $1, $3);
        }

    | expression LTE expression
        {
            $$ = new BinaryExpr("<=", $1, $3);
        }

    | expression AND expression
        {
            $$ = new BinaryExpr("&&", $1, $3);
        }

    | expression OR expression
        {
            $$ = new BinaryExpr("||", $1, $3);
        }

    | NOT expression
        {
            $$ = new UnaryExpr("!", $2);
        }

    | '-' expression %prec UMINUS
        {
            $$ = new UnaryExpr("-", $2);
        }

    | TRUE
        {
            $$ = new BoolExpr(true);
        }

    | FALSE
        {
            $$ = new BoolExpr(false);
        }
;

local_var_decl:
      type IDENTIFIER ';'
      {
          VariableDecl var;

          var.type = $1;
          var.name = $2;
          var.expr = nullptr;

          $$ = new VariableDeclStmt(var);
      }

    | type IDENTIFIER '=' expression ';'
      {
          VariableDecl var;

          var.type = $1;
          var.name = $2;
          var.expr = $4;

          $$ = new VariableDeclStmt(var);
      }
;

%%

extern char* yytext;

void yyerror(const char *s)
{
    printf(
        "Parse Error: %s near '%s'\n",
        s,
        yytext
    );
}